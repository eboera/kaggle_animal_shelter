import numpy
import scipy
import pylab  # libraries
from pylab import *
from numpy import *
import math
import matplotlib.pyplot as plt
import pickle
import pandas as pd
import sys
from scipy import signal
from scipy import fftpack
from scipy.signal import argrelextrema
import random
import pickle
import csv
from numpy import genfromtxt
from scipy.signal import argrelextrema
from scipy.interpolate import interp1d
import pylab as mpl
from scipy import interpolate
from scipy import interpolate
from scipy.interpolate import interp1d
import random
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.externals import joblib
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import brier_score_loss##########################
#open new data

def TransformOutcome(Sampleseq,data):

  SampleLabels=[]   
  for x in Sampleseq:
    Outcome=data['OutcomeType'][x]  

    if Outcome=='Adoption':
     SampleLabels.append(0)
    elif Outcome=='Return_to_owner':
     SampleLabels.append(1)
    elif Outcome=='Transfer':
     SampleLabels.append(2)
    elif Outcome=='Died':
     SampleLabels.append(3)  
    elif Outcome=='Euthanasia':
     SampleLabels.append(4)   
  
  return SampleLabels    

def CreateInputMatrix(Sampleseq,data,Agearray):
  AnimalType=[]
  AnimalAge=[]
  Animalsex=[]
  AnimalStatus=[]
  AnimalSize=[]


  for tr in Sampleseq:
    Type=data['AnimalType'][tr]
    if Type=='Dog':
       AnimalType.append(1)
    elif Type=='Cat':
       AnimalType.append(0)
  
    Age=Agearray[tr] 
    AnimalAge.append(Age)
  
    sex=data['sex'][tr]
    if sex=='Female':
       Animalsex.append(1)
    elif sex=='Male':
       Animalsex.append(2)
    else:
       Animalsex.append(0)

    Status=data['desexed'][tr]
    if Status=='Yes':
       AnimalStatus.append(1)
    elif Status=='No':
       AnimalStatus.append(2)
    else:
       AnimalStatus.append(0)

    Size=data['dogsize'][tr]
    if Size=='s':
       AnimalSize.append(1)
    elif Size=='m':
       AnimalSize.append(2)
    elif Size=='l':
       AnimalSize.append(3)
    elif Size=='u':
       AnimalSize.append(0)
  

  Matrix=array([AnimalType, AnimalAge, Animalsex, AnimalStatus, AnimalSize]).transpose()  
  return Matrix

def ComputeAccuracy(SampleLabels,predictions):
 nc=0
 nw=0
 ntot=len(predictions)
 i=0
 for p in predictions:

    if p==SampleLabels[i]:
       nc=(nc+1)
       i=(i+1) 

       
    else:
       nw=(nw+1)
       i=(i+1)
      

 Accuracy=float(nc)/float(ntot)      
 return Accuracy
