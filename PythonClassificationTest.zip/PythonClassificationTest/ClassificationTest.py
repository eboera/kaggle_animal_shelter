import numpy
import scipy
import pylab  # libraries
from pylab import *
from numpy import *
import math
import matplotlib.pyplot as plt
import pickle
import pandas as pd
import sys
import random
import csv
from numpy import genfromtxt
from scipy.interpolate import interp1d
from scipy import interpolate

from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.externals import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import brier_score_loss
from ClassificationFunctions import *

##########################
#open new data

data_path = './train_prep.csv'

data=pd.read_csv(data_path)

ID=data['AnimalID']
#clean from Nan
Agearray=data['AgeuponOutcome_days'].fillna(0)

# separate the dataset in training and testing samples
TrainSampleLabels=[]
TestSampleLabels=[]

TotNSample=len(ID)

NTrainSample=int(round(TotNSample*0.8))
NTestSample=(TotNSample-NTrainSample)

TrainSampleseq=random.sample(xrange(TotNSample), NTrainSample)
TestSampleseq=list(set(arange(0,TotNSample))-set(TrainSampleseq))

TrainSampleS=arange(0,NTrainSample) 
TestSampleS=arange(0,NTestSample) 


#translate outcome labels into numerical values

TrainSampleLabels=TransformOutcome(TrainSampleseq,data)
TestSampleLabels=TransformOutcome(TestSampleseq,data)

##########################################
#create input matrix

TrainMatrix=CreateInputMatrix(TrainSampleseq,data,Agearray)
TestMatrix=CreateInputMatrix(TestSampleseq,data,Agearray)
#TODO:add info about date and time outcome+ specific info about breed

# try basic machine learning models

#Support Vector Classifier
model= svm.SVC(decision_function_shape='ovr', probability=True)
model.fit(TrainMatrix,TrainSampleLabels)

pred=model.predict(TestMatrix)

Accuracy=ComputeAccuracy(TestSampleLabels,pred)
print "Accuracy SVC", Accuracy


print "Confusion matrix SVM"


y_actu = pd.Series(TestSampleLabels, name='Real')
y_pred = pd.Series(pred, name='Predicted')
df_confusion = pd.crosstab(y_actu, y_pred)
print df_confusion

###########################
#Basic Decison Tree
model2=DecisionTreeClassifier()
model2.fit(TrainMatrix,TrainSampleLabels)
pred2=model2.predict(TestMatrix)


AccuracyT=ComputeAccuracy(TestSampleLabels,pred2)

print "Accuracy Decision Tree", AccuracyT

print "confusion matrix Decision Tree"


y_actuT = pd.Series(TestSampleLabels, name='Real')
y_predT = pd.Series(pred2, name='Predicted')
df_confusionT = pd.crosstab(y_actuT, y_predT)
print df_confusionT

###################
#K-Neighbours

model3=KNeighborsClassifier()
model3.fit(TrainMatrix,TrainSampleLabels)
pred3=model3.predict(TestMatrix)

AccuracyK=ComputeAccuracy(TestSampleLabels,pred3)

print "Accuracy Kneighbors", AccuracyK


print "confusion matrix Kneighbors"


y_actuK = pd.Series(TestSampleLabels, name='Real')
y_predK = pd.Series(pred3, name='Predicted')
df_confusionK = pd.crosstab(y_actuK, y_predK)
print df_confusionK
###################################
#RandomForest

model4=RandomForestClassifier()
model4.fit(TrainMatrix,TrainSampleLabels)
pred4=model4.predict(TestMatrix)

AccuracyF=ComputeAccuracy(TestSampleLabels,pred4)

print "Accuracy Random Forest", AccuracyF


print "confusion matrix RandomForest"


y_actuF = pd.Series(TestSampleLabels, name='Real')
y_predF = pd.Series(pred4, name='Predicted')
df_confusionF = pd.crosstab(y_actuF, y_predF)
print df_confusionF



